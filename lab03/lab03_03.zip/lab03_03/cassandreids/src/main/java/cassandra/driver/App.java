package cassandra.driver;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.Row;

public class App {
    static Session session;

    public static void main( String[] args )
    {
       
    }

    public static void connect(String node, int port) {
        Cluster cluster = Cluster.builder()
            .addContactPoint(node)
            .withPort(port)
            .build();
        session = cluster.connect();
        System.out.println("Connected to cluster: " + cluster.getMetadata().getClusterName());
    }

}   
